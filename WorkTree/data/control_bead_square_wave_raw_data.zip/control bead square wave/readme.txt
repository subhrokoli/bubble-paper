These are the displacements as a function of time for the trapping light to the control bead being moved in a 
square wave fashion. The total time series corresponds to 5 seconds. 